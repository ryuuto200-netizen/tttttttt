# 社特Ⅲ 政治D〜H 赤シート練習

GitHub Pages用の分割版です。
